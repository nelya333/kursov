import React from 'react';

const BasketComponent = () => {
    return (
        <div>
            <h1>basket-component</h1>
        </div>
    );
};

export default BasketComponent;